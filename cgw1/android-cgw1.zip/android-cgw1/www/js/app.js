/*
 * Please see the included README.md file for license terms and conditions.
 */


// This file is a suggested starting place for your code.
// It is completely optional and not required.
// Note the reference that includes it in the index.html file.


/*jslint browser:true, devel:true, white:true, vars:true */
/*global $:false, intel:false app:false, dev:false, cordova:false */


// For improved debugging and maintenance of your app, it is highly
// recommended that you separate your JavaScript from your HTML files.
// Use the addEventListener() method to associate events with DOM elements.

// For example:

// var el ;
// el = document.getElementById("id_myButton") ;
// el.addEventListener("click", myEventHandler, false) ;



// The function below is an example of the best way to "start" your app.
// This example is calling the standard Cordova "hide splashscreen" function.
// You can add other code to it or add additional functions that are triggered
// by the same event or other events.

function onAppReady() {
    if( navigator.splashscreen && navigator.splashscreen.hide ) {   // Cordova API detected
        navigator.splashscreen.hide() ;
    }
}
document.addEventListener("app.Ready", onAppReady, false) ;

window.addEventListener('resize', function() {
    let athlete = document.getElementById('athlete');
    
    if (window.innerHeight > window.innerWidth) {
        // Портретный режим — занимаемся спортом
        athlete.src = 'https://media1.tenor.com/m/vwnunVTPL_4AAAAC/fixik-fixiki.gif'; // Ваша анимация для спорта
    } else {
        // Альбомный режим — спим
        athlete.src = 'https://media.tenor.com/JytsJ0Mlb8wAAAAM/sleep-time.gif'; // Ваша анимация для сна
    }
});

// Устанавливаем начальную анимацию в зависимости от ориентации
window.addEventListener('load', function() {
    const athlete = document.getElementById('athlete');
    
    if (window.innerHeight > window.innerWidth) {
        athlete.src = 'https://media1.tenor.com/m/vwnunVTPL_4AAAAC/fixik-fixiki.gif'; // Ваша анимация для спорта
    } else {
        athlete.src = 'https://media.tenor.com/JytsJ0Mlb8wAAAAM/sleep-time.gif'; // Ваша анимация для сна
    }
});

